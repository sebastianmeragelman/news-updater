<?php
/*
Plugin Name: Importador JSON desde Drive
Description: Importa posts desde JSON público (estable, sin problemas de CSV)
Version: 1.0
*/

if (!defined('ABSPATH')) exit;

// 🔧 CONFIG  SE DEBE AGREGAR LUEGO DEL ID= EL ID DEL ARCHIVO JSON CON LA FUENTE DE DATOS
define('JSON_URL', 'https://drive.google.com/uc?export=download&id=   ');

// 🚀 FUNCIÓN PRINCIPAL
function importar_desde_json() {

    echo "<pre>🚀 Iniciando importación JSON...</pre>";

    $response = wp_remote_get(JSON_URL);

    if (is_wp_error($response)) {
        echo "<pre>❌ Error HTTP</pre>";
        return;
    }

    $body = wp_remote_retrieve_body($response);

    if (!$body) {
        echo "<pre>❌ JSON vacío</pre>";
        return;
    }

    echo "<pre>✅ JSON recibido</pre>";

    $data = json_decode($body, true);

    if (!$data) {
        echo "<pre>❌ Error parseando JSON</pre>";
        return;
    }

    echo "<pre>Total registros: " . count($data) . "</pre>";

    foreach ($data as $item) {

        echo "<pre>-----------------------------</pre>";
        print_r($item);

        $id_ext     = $item['id'] ?? '';
        $categoria  = $item['categoria'] ?? 'General';
        $titulo     = $item['titulo'] ?? '';
        $contenido  = $item['contenido'] ?? '';
        $imagen_url = $item['imagen_url'] ?? '';
        $estado     = $item['estado'] ?? 'draft';

        if (!$titulo) {
            echo "<pre>⚠️ Sin título</pre>";
            continue;
        }

        // 🔎 evitar duplicados
        $existing = get_posts([
            'meta_key' => 'drive_id',
            'meta_value' => $id_ext,
            'post_type' => 'post'
        ]);

        if ($existing) {
            echo "<pre>⏭️ Ya existe ID: $id_ext</pre>";
            continue;
        }

        // 📂 categoría
        $cat_id = obtener_o_crear_categoria_json($categoria);

        // 📝 crear post
        $post_id = wp_insert_post([
            'post_title'   => wp_strip_all_tags($titulo),
            'post_content' => $contenido,
            'post_status'  => $estado,
            'post_category'=> [$cat_id],
            'post_date'    => current_time('mysql'),
        ]);

        if (is_wp_error($post_id)) {
            echo "<pre>❌ Error creando post</pre>";
            continue;
        }

        echo "<pre>✅ Post creado ID: $post_id</pre>";

        update_post_meta($post_id, 'drive_id', $id_ext);

        // 🖼️ imagen (opcional)
        if ($imagen_url) {
            setear_imagen_destacada_json($imagen_url, $post_id);
        }
    }

    echo "<pre>🏁 Importación finalizada</pre>";
}

// 📂 categoría
function obtener_o_crear_categoria_json($nombre) {

    $term = term_exists($nombre, 'category');

    if ($term !== 0 && $term !== null) {
        return $term['term_id'];
    }

    $nuevo = wp_insert_term($nombre, 'category');

    if (is_wp_error($nuevo)) return 1;

    return $nuevo['term_id'];
}

// 🖼️ imagen destacada
function setear_imagen_destacada_json($url, $post_id) {

    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    // 🔥 HEADERS para evitar bloqueo CDN
    $args = [
        'timeout' => 20,
        'headers' => [
            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'Referer'    => 'https://www.lanacion.com.ar/'
        ]
    ];

    $response = wp_remote_get($url, $args);

    if (is_wp_error($response)) {
        return;
    }

    $body = wp_remote_retrieve_body($response);

    if (!$body) {
        return;
    }

    // nombre archivo
    $filename = basename(parse_url($url, PHP_URL_PATH));

    if (!$filename) {
        $filename = 'imagen.jpg';
    }

    // crear archivo temporal
    $upload_dir = wp_upload_dir();
    $file_path = $upload_dir['path'] . '/' . $filename;

    file_put_contents($file_path, $body);

    $filetype = wp_check_filetype($filename, null);

    $attachment = [
        'post_mime_type' => $filetype['type'],
        'post_title'     => sanitize_file_name($filename),
        'post_content'   => '',
        'post_status'    => 'inherit'
    ];

    $attach_id = wp_insert_attachment($attachment, $file_path, $post_id);

    $attach_data = wp_generate_attachment_metadata($attach_id, $file_path);
    wp_update_attachment_metadata($attach_id, $attach_data);

    set_post_thumbnail($post_id, $attach_id);
}

////function setear_imagen_destacada_json($url, $post_id) {

    //require_once(ABSPATH . 'wp-admin/includes/file.php');
    //require_once(ABSPATH . 'wp-admin/includes/media.php');
    //require_once(ABSPATH . 'wp-admin/includes/image.php');

    //$tmp = download_url($url);

    //if (is_wp_error($tmp)) return;

    //$file_array = [
     //   'name'     => basename($url),
     //   'tmp_name' => $tmp
    //];

    //$attachment_id = media_handle_sideload($file_array, $post_id);

    //if (!is_wp_error($attachment_id)) {
    //    set_post_thumbnail($post_id, $attachment_id);
   // }
//}

// 🔘 menú admin
add_action('admin_menu', function() {
    add_menu_page('Importador JSON', 'Importador JSON', 'manage_options', 'importador-json', 'vista_admin_json');
});

function vista_admin_json() {

    echo "<h2>Importador JSON</h2>";

    if (isset($_POST['ejecutar'])) {
        importar_desde_json();
    }

    echo '<form method="post">
        <button name="ejecutar" style="padding:10px 20px;font-size:16px;">Ejecutar ahora</button>
    </form>';
}


register_activation_hook(__FILE__, 'json_importer_cron_activate');

function json_importer_cron_activate() {
    if (!wp_next_scheduled('json_importer_event')) {
        wp_schedule_event(time(), 'hourly', 'json_importer_event');
    }
}
